# iPadWatchBridge — initial-pairing research prototype

This project is a legitimate interoperability prototype for an Apple Watch owned by the tester.

## Current prototype
- iPadOS SwiftUI application
- Sign in with Apple system authorization UI
- CoreBluetooth discovery of nearby devices named like Apple Watch
- Camera preview for the Apple Watch animated pairing pattern
- GitHub Actions workflow that generates an Xcode project with XcodeGen and packages an unsigned IPA as `test.ipa`

## Important: activation
Apple's public documentation says initial Apple Watch pairing requires an activation certificate from Apple's activation service. The public App Store Connect certificate APIs are **not** that service. This repository deliberately does not invent or spoof an activation endpoint and does not attempt to bypass Activation Lock.

The next research layer is the proprietary pairing/activation protocol. WatchWitch and its Wireshark tooling provide public reverse-engineering references, but their documented implementation targets older watchOS versions and is not a drop-in implementation for current watchOS.

## Build
Open `project.yml` with XcodeGen or run the GitHub Action. The Action produces `test.ipa` as an artifact.

## Testing
Use an erased/unpaired Apple Watch that you own. The camera screen currently provides the capture UI; decoding and the Apple activation handshake are not implemented yet.
