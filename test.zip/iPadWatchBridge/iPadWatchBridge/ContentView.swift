import SwiftUI

struct ContentView: View {
    @StateObject private var scanner = WatchScanner()
    @State private var showScanner = false
    @State private var showSignIn = false

    var body: some View {
        NavigationStack {
            List {
                Section("Apple Account") {
                    Button("Sign in with Apple") { showSignIn = true }
                    Text("Authentication uses Apple's system sign-in UI. This app never asks for or sends your Apple Account password to us.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("Initial Apple Watch Pairing") {
                    Button("Start pairing") { showScanner = true }
                    Text("Scan the animated pairing pattern shown by an erased/unpaired Apple Watch.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("Bluetooth") {
                    Button(scanner.isScanning ? "Stop scanning" : "Scan for Apple Watch") {
                        scanner.isScanning ? scanner.stop() : scanner.start()
                    }
                    ForEach(scanner.devices) { device in
                        VStack(alignment: .leading) {
                            Text(device.name)
                            Text(device.id.uuidString).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                Section("Pairing state") {
                    Text(scanner.state)
                }
            }
            .navigationTitle("iPadWatchBridge")
            .sheet(isPresented: $showScanner) { PairingCameraView() }
            .sheet(isPresented: $showSignIn) { AppleSignInView() }
        }
    }
}
