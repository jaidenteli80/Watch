import Foundation
import CoreBluetooth
import Combine

struct WatchDevice: Identifiable {
    let id: UUID
    let name: String
}

final class WatchScanner: NSObject, ObservableObject, CBCentralManagerDelegate {
    @Published var devices: [WatchDevice] = []
    @Published var isScanning = false
    @Published var state = "Waiting"
    private var central: CBCentralManager!

    override init() {
        super.init()
        central = CBCentralManager(delegate: self, queue: nil)
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        DispatchQueue.main.async { self.state = central.state == .poweredOn ? "Bluetooth ready" : "Bluetooth: \(central.state.rawValue)" }
    }

    func start() {
        guard central.state == .poweredOn else { state = "Bluetooth is not powered on"; return }
        devices.removeAll(); isScanning = true; state = "Scanning…"
        central.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
    }

    func stop() { central.stopScan(); isScanning = false; state = "Scan stopped" }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        let name = peripheral.name ?? (advertisementData[CBAdvertisementDataLocalNameKey] as? String) ?? "Unnamed BLE device"
        guard name.localizedCaseInsensitiveContains("Watch") else { return }
        if !devices.contains(where: { $0.id == peripheral.identifier }) {
            devices.append(WatchDevice(id: peripheral.identifier, name: name))
            state = "Found \(name)"
        }
    }
}
