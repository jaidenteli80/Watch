import SwiftUI

@main
struct iPadWatchBridgeApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
