import SwiftUI
import AuthenticationServices

struct AppleSignInView: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "apple.logo").font(.system(size: 60))
            Text("Apple Account").font(.largeTitle.bold())
            SignInWithAppleButton(.signIn, onRequest: { request in
                request.requestedScopes = [.fullName, .email]
            }, onCompletion: { result in
                switch result {
                case .success(let authorization):
                    print("Apple authorization received: \(authorization)")
                    dismiss()
                case .failure(let error):
                    print("Apple authorization failed: \(error)")
                }
            })
            .frame(height: 50).padding(.horizontal)
            Text("The app uses Apple's authorization UI. It does not collect your Apple Account password or verification code itself.")
                .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center).padding()
        }.padding()
    }
}
