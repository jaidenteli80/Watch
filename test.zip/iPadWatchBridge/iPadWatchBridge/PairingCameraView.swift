import SwiftUI
import AVFoundation

struct PairingCameraView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var camera = CameraController()
    var body: some View {
        NavigationStack {
            ZStack {
                CameraPreview(session: camera.session).ignoresSafeArea()
                RoundedRectangle(cornerRadius: 28).stroke(.white, lineWidth: 4).frame(width: 330, height: 330)
                VStack { Spacer(); Text("Center the Apple Watch animated pairing pattern inside the frame").padding().background(.thinMaterial).clipShape(RoundedRectangle(cornerRadius: 16)).padding() }
            }
            .navigationTitle("Scan Apple Watch")
            .toolbar { ToolbarItem(placement: .topBarLeading) { Button("Cancel") { dismiss() } } }
            .task { await camera.start() }
            .onDisappear { camera.stop() }
        }
    }
}

final class CameraController: NSObject, ObservableObject {
    let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "watchbridge.camera")
    func start() async {
        guard await AVCaptureDevice.requestAccess(for: .video) else { return }
        queue.async {
            guard !self.session.isRunning else { return }
            guard let device = AVCaptureDevice.default(for: .video), let input = try? AVCaptureDeviceInput(device: device), self.session.canAddInput(input) else { return }
            self.session.beginConfiguration(); self.session.addInput(input); self.session.commitConfiguration(); self.session.startRunning()
        }
    }
    func stop() { queue.async { if self.session.isRunning { self.session.stopRunning() } } }
}

struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession
    func makeUIView(context: Context) -> PreviewView { let v = PreviewView(); v.videoPreviewLayer.session = session; v.videoPreviewLayer.videoGravity = .resizeAspectFill; return v }
    func updateUIView(_ uiView: PreviewView, context: Context) { uiView.videoPreviewLayer.session = session }
}
final class PreviewView: UIView { override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }; var videoPreviewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer } }
